In this activity, you'll be editing and submitting `src/todo.ts`. Running and
reading through the code in `src/example.ts` is highly recommended.

### Setup project

```
npm install
```

### Run example code

```
node src/example.ts
```

### Run and time your code

```
node src/runner.ts
```
