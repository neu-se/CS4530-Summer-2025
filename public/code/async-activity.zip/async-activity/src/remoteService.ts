import axios, { type AxiosResponse } from 'axios';

// all references to axios are localized here

// where to send the requests
axios.defaults.baseURL = 'https://rest-example.covey.town';

export async function remoteGet<T>(path: string): Promise<T> {
  const response: AxiosResponse<T> = await axios.get(path);
  return response.data;
}

export async function remoteDelete<T>(path: string): Promise<T> {
  const response: AxiosResponse<T> = await axios.delete(path);
  return response.data;
}

export async function remotePost<T>(path: string, data?: unknown): Promise<T> {
  const response: AxiosResponse<T> = await axios.post(path, data);
  return response.data;
}
