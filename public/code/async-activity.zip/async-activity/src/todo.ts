import { type Transcript, type TranscriptToImport } from './types.ts';
import { addGrade, addStudent, getTranscript } from './client.ts';

export async function importGrades1(
  gradesToImport: TranscriptToImport[],
): Promise<Transcript[]> {
  // For each student, sequentially in order:
  //   Add the student with addStudent
  //   Then insert each grade sequentially in order with addGrade
  // When all students have all their grades submitted:
  //   Fetch transcripts for each student sequentially in order
  return [];
}

export async function importGrades2(
  gradesToImport: TranscriptToImport[],
): Promise<Transcript[]> {
  // For all students concurrently:
  //   Add the student with addStudent
  //   Then insert each grade sequentially in order with addGrade
  //   Then fetch the transcript with getTranscript
  return [];
}

export async function importGrades3(
  gradesToImport: TranscriptToImport[],
): Promise<Transcript[]> {
  // For all students concurrently:
  //   Add the student with addStudent
  //   Then insert all grades concurrently
  // When all students have all their grades submitted:
  //   Fetch transcripts for all students concurrently
  return [];
}
