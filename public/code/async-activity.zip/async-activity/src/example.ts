import { addGrade, addStudent, getTranscript } from './client.ts';

// Here is some example code that makes the API calls that you will need to
// use (addStudent, addGrade, and getTranscript)

console.log('Creating a student');
const { studentID } = await addStudent('test student');

console.log('Adding four grades');
await addGrade(studentID, 'first demo course', 100);
await addGrade(studentID, 'second demo course', 100);
await addGrade(studentID, 'third demo course', 100);
await addGrade(studentID, 'fourth demo course', 100);

console.log('Getting a transcript');
const transcript = await getTranscript(studentID);
console.log(transcript);

// Here are some iteration patterns that may be useful:

console.log(
  `\n---\nDemo of using a for-of loop to go through the grades sequentially`,
);
for (const { course, grade } of transcript.grades) {
  console.log(`${course}: ${grade}`);
}

console.log(
  `\n---\nDemo of using Promise.all and setTimeout to go through the grades in a random order`,
);
await Promise.all(
  transcript.grades.map(async ({ course, grade }) => {
    // Wait a random amount of time
    await new Promise(resolve => setTimeout(resolve, Math.random() * 10));
    // After the random amount of time, print the grade
    console.log(`${course}: ${grade}`);
  }),
);
