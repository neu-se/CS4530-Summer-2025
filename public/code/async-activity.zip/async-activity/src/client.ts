import { remoteGet, remotePost } from './remoteService.ts';
import type { Transcript } from './types.ts';

/**
 * POST `/transcripts`
 * -- adds a new student to the database, returns an ID for this student.
 * -- Requires a post parameter 'name'.
 * -- Multiple students may have the same name.
 */
export async function addStudent(
  studentName: string,
): Promise<{ studentID: number }> {
  return remotePost('/transcripts', { name: studentName });
}

/**
 * GET `/transcripts/:studentID`
 * -- returns name transcript for student with given ID.  Fails if no such student
 */
export async function getTranscript(studentID: number): Promise<Transcript> {
  return remoteGet(`/transcripts/${studentID}`);
}

/**
 * POST `/transcripts/:studentID/:courseName`
 * -- adds an entry in this student's transcript with given name and course.
 * -- Requires a post parameter 'grade'. Fails if there is already an entry for this course in the student's transcript
 */
export async function addGrade(
  studentID: number,
  courseName: string,
  grade: number,
): Promise<{ grade: number }> {
  return remotePost(`/transcripts/${studentID}/${courseName}`, { grade });
}
