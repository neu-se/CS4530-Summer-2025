// manage the transcript database

export type Student = { studentID: number; studentName: string };
export type CourseGrade = { course: string; grade: number };
export type Transcript = { student: Student; grades: CourseGrade[] };

export type TranscriptToImport = {
  studentName: string;
  grades: CourseGrade[];
};
