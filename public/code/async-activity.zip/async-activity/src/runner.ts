import { importGrades1, importGrades2, importGrades3 } from './todo.ts';
import type { TranscriptToImport } from './types.ts';

const SAMPLE_DATA: TranscriptToImport[] = [
  {
    studentName: 'Avery',
    grades: [
      { course: 'Software Engineering', grade: 100 },
      { course: 'Chemistry', grade: 70 },
      { course: 'Geology', grade: 84 },
    ],
  },
  {
    studentName: 'Ripley',
    grades: [
      { course: 'Underwater Basket Weaving', grade: 100 },
      { course: 'Kayaking', grade: 90 },
    ],
  },
  {
    studentName: 'Nalini',
    grades: [
      { course: 'Representational Art', grade: 93 },
      { course: 'Physics', grade: 91 },
      { course: 'Comparative Literature', grade: 83 },
    ],
  },
];

async function testImplementation(
  gradesToImport: TranscriptToImport[],
  implementationNumber: 1 | 2 | 3,
) {
  console.log(`------\ntesting importGrades${implementationNumber}`);
  const t0 = performance.now();
  const transcripts =
    implementationNumber === 1
      ? await importGrades1(gradesToImport)
      : implementationNumber === 2
        ? await importGrades2(gradesToImport)
        : await importGrades3(gradesToImport);
  const t1 = performance.now();

  console.log(`importGrades${implementationNumber} completed, and returned:`);
  console.log(JSON.stringify(transcripts, null, 2));
  console.log('Elapsed time:', (t1 - t0).toFixed(2), 'milliseconds\n\n');
}

await testImplementation(SAMPLE_DATA, 1);
await testImplementation(SAMPLE_DATA, 2);
await testImplementation(SAMPLE_DATA, 3);
