import { type GameInfo, type GameKey, type TaggedGameView } from '@strategy-town/shared';
import { createChat } from './chat.service.ts';
import { randomUUID } from 'node:crypto';
import { populateSafeUserInfo } from './user.service.ts';
import { type GameServicer } from '../games/gameServiceManager.ts';
import { nimGameService } from '../games/nim.ts';
import { guessGameService } from '../games/guess.ts';
import { type GameViewUpdates, type ObjectId, type Types, type UserWithId } from '../types.ts';

/**
 * The service interface for individual games
 */
export const gameServices: { [key in GameKey]: GameServicer } = {
  nim: nimGameService,
  guess: guessGameService,
};

/**
 * Represents a game document in the database.
 * - `type`: picks which game this is
 * - `state`: absent if the game hasn't started, or the id for the game's state
 * - `chat`: id for the game's chat
 * - `players`: active players for the game
 * - `createdAt`: when the game was created
 * - `createdBy`: username of the person who created the game
 */
interface GameRecord {
  type: GameKey;
  state?: unknown;
  done: boolean;
  chat: ObjectId; // References Chat records
  players: Types.ObjectId[]; // References User records
  createdAt: Date;
  createdBy: Types.ObjectId; // References User records
}
let storedGames: { [_id: string]: GameRecord } = {};

/** Reset stored games with example data. */
export function resetStoredGames() {
  const recently = new Date(new Date().getTime() - 6 * 60 * 60 * 1000);
  storedGames = {
    [randomUUID().toString()]: {
      type: 'nim',
      state: { remaining: 0, nextPlayer: 1 },
      done: true,
      chat: createChat(new Date('2025-04-21'))._id,
      players: ['user2id', 'user3id'],
      createdAt: new Date('2025-04-21'),
      createdBy: 'user2id',
    },
    [randomUUID().toString()]: {
      type: 'guess',
      state: { secret: 43, guesses: [null, 2, 99, null] },
      done: false,
      chat: createChat(recently)._id,
      players: ['user1id', 'user0id', 'user3id', 'user2id'],
      createdAt: recently,
      createdBy: 'user1id',
    },
    [randomUUID().toString()]: {
      type: 'nim',
      done: false,
      chat: createChat(new Date())._id,
      players: ['user1id'],
      createdAt: new Date(),
      createdBy: 'user1id',
    },
  };
}

/**
 * Expand a stored game
 *
 * @param _id - Valid game id
 * @returns the expanded game info object
 */
function populateGameInfo(_id: string): GameInfo {
  const game = storedGames[_id];
  return {
    _id,
    createdBy: populateSafeUserInfo(game.createdBy),
    chat: game.chat,
    createdAt: game.createdAt,
    players: game.players.map(populateSafeUserInfo),
    type: game.type,
    status: !game.state ? 'waiting' : game.done ? 'done' : 'active',
    minPlayers: gameServices[game.type].minPlayers,
  };
}

/**
 * Create and store a new game
 *
 * @param user - Initial player in the game's waiting room
 * @param type - Game key
 * @param createdAt - Creation time for this game
 * @returns the new game's info object
 */
export function createGame(user: UserWithId, type: GameKey, createdAt: Date): GameInfo {
  const gameId = randomUUID().toString();
  const chat = createChat(createdAt);
  const game: GameRecord = {
    type,
    done: false,
    chat: chat._id,
    createdAt,
    createdBy: user._id,
    players: [user._id],
  };
  storedGames[gameId] = game;
  return populateGameInfo(gameId);
}

/**
 * Retrieves a single game from the database. If you expect the id to be valid, use `forceGameById`.
 *
 * @param gameId - Ostensible game id
 * @returns the game's info object, or null
 */
export function getGameById(gameId: string): GameInfo | null {
  const game = storedGames[gameId];
  if (!game) return null;
  return populateGameInfo(gameId);
}

/**
 * Adds a user to a game that hasn't started yet. If the resulting game object has the maximum
 * allowed number of players, it is the responsibility of the caller to start the game.
 *
 * @param gameId - Ostensible game id
 * @param user - Authenticated user
 * @returns the game's info object, with the `user` listed among the players
 * @throws if the game id is not valid, if the game has started, or if the game cannot accept more
 * players
 */
export function joinGame(gameId: string, user: UserWithId): GameInfo {
  const game = storedGames[gameId];
  if (!game) throw new Error(`user ${user.username} joining invalid game`);
  if (game.state) {
    throw new Error(`user ${user.username} joining game that started`);
  }
  if (game.players.some(_id => _id === user._id)) {
    throw new Error(`user ${user.username} joining game they are in already`);
  }
  if (game.players.length === gameServices[game.type].maxPlayers) {
    throw new Error(`user ${user.username} joining full`);
  }

  game.players = [...game.players, user._id];

  return populateGameInfo(gameId);
}

/**
 * Initializes a game that hasn't started yet
 *
 * @param gameId - Ostensible game id
 * @param user - Authenticated user
 * @returns the necessary views for everyone watching the game
 * @throws if the game id is not valid, if the game already started, or if the game lacks enough
 * players to start
 */
export function startGame(gameId: string, user: UserWithId): GameViewUpdates {
  const game = storedGames[gameId];
  if (!game) throw new Error(`user ${user.username} starting invalid game`);
  if (game.state) {
    throw new Error(`user ${user.username} starting game that started`);
  }

  const key: GameKey = game.type;

  if (game.players.length < gameServices[key].minPlayers) {
    throw new Error(`user ${user.username} starting underpopulated game`);
  }
  if (!game.players.some(_id => _id === user._id)) {
    throw new Error(`user ${user.username} starting game they're not in`);
  }
  const { state, views } = gameServices[key].create(game.players);

  game.state = state;

  return views;
}

/**
 * Get a list of all games
 *
 * @returns a list of game summaries, ordered reverse chronologically
 */
export function getGames(): GameInfo[] {
  const unsorted = Object.keys(storedGames).map(populateGameInfo);

  return unsorted.toSorted((game1, game2) => game2.createdAt.getTime() - game1.createdAt.getTime());
}

/**
 * Updates a game state and returns the necessary view updates
 *
 * @param gameId - Ostensible game id
 * @param user - Authenticated user
 * @param move - Unsanitized game move
 * @returns the view updates to send to players and watchers
 * @throws if the game id or move is not valid
 */
export function updateGame(gameId: string, user: UserWithId, move: unknown) {
  const game = storedGames[gameId];
  if (!game) throw new Error(`user ${user.username} acted on an invalid game`);
  if (!game.state) {
    throw new Error(`user ${user.username} made a move in game of that hadn't started`);
  }
  const playerIndex = game.players.findIndex(_id => _id === user._id);
  if (playerIndex < 0) {
    throw new Error(`user ${user.username} made a move in a game they weren't playing`);
  }
  const result = gameServices[game.type].update(game.state, move, playerIndex, game.players);
  if (!result) throw new Error(`user ${user.username} made an invalid move in ${game.type}`);

  game.state = result.state;
  game.done = game.done || result.done;

  return result.views;
}

/**
 * View a game as a specific user
 * @param gameId - Ostensible game id
 * @param user - Authenticated user
 * @returns A boolean for whether that user is a player, the player's view, and the list of players
 */
export function viewGame(gameId: string, user: UserWithId) {
  const game = storedGames[gameId];
  if (!game) throw new Error(`user ${user.username} viewed an invalid game id`);
  const playerIndex = game.players.findIndex(_id => _id === user._id);
  let view: TaggedGameView | null = null;
  if (game.state) {
    view = gameServices[game.type].view(game.state, playerIndex);
  }
  return {
    isPlayer: playerIndex >= 0,
    view,
    players: game.players.map(populateSafeUserInfo),
  };
}
