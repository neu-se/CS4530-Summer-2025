import { type SafeUserInfo, type UserAuth, type UserUpdateRequest } from '@strategy-town/shared';
import { randomUUID } from 'node:crypto';
import { type UserWithId } from '../types.ts';

const disallowedUsernames = new Set(['login', 'signup', 'list']);

/**
 * Represents a user document in the database.
 * - `password`: user's password
 * - `display`: A display name
 * - `createdAt`: when this user registered.
 */
interface UserRecord {
  username: string;
  password: string;
  display: string;
  createdAt: Date;
}
let storedUsers: { [username: string]: UserRecord } = {};
let usernameIndex: { [username: string]: string } = {};

/** Reset stored users with example data */
export function resetStoredUsers() {
  storedUsers = {
    user0id: {
      username: 'user0',
      password: 'pwd0',
      display: 'Strategy.town webmaster',
      createdAt: new Date('2024-11-12'),
    },
    user1id: {
      username: 'user1',
      password: 'pwd1',
      display: 'Yāo',
      createdAt: new Date('2025-01-02'),
    },
    user2id: {
      username: 'user2',
      password: 'pwd2',
      display: 'Sénior Dos',
      createdAt: new Date('2025-03-04'),
    },
    user3id: {
      username: 'user3',
      password: 'pwd3',
      display: 'Frau Drei',
      createdAt: new Date('2025-01-01'),
    },
  };

  usernameIndex = Object.fromEntries(
    Object.entries(storedUsers).map(([_id, { username }]) => [username, _id]),
  );
}

/**
 * Retrieves a single user from the database.
 *
 * @param _id - Valid user id.
 * @returns the found user object (without the password).
 */
export function populateSafeUserInfo(_id: string): SafeUserInfo {
  const record = storedUsers[_id];
  return {
    username: record.username,
    display: record.display,
    createdAt: record.createdAt,
  };
}

/**
 * Takes a username and password, and either returns the corresponding user object
 * (without the password) or null if the username/password combination does not
 * match stored values.
 *
 * @param auth - A user's authentication information (username and password)
 * @returns the corresponding user object (without the password) or null.
 */
export function checkAuth({ username, password }: UserAuth): UserWithId | null {
  const id = usernameIndex[username];
  const user = storedUsers[id];
  if (!user) return null;
  if (password !== user.password) return null;
  return { _id: id, username: user.username };
}

/**
 * Takes a username and password, and returns the corresponding user
 * (without the password) or an error if the username/password combination
 * doesn't match stored values.
 *
 * @param auth - A user's authentication information (username and password)
 * @returns the corresponding user object (without the password)
 * @throws if the auth information is incorrect
 */
export function enforceAuth(auth: UserAuth): UserWithId {
  const user = checkAuth(auth);
  if (!user) throw new Error('Invalid auth');
  return user;
}

/**
 * Create and store a new user
 *
 * @param newUser - The user object to be saved, containing user details like username, password, etc.
 * @returns Resolves with the saved user object (without the password) or an error message.
 */
export function createUser(username: string, password: string, createdAt: Date) {
  if (username in usernameIndex) {
    return { error: 'User already exists' };
  }
  if (disallowedUsernames.has(username)) {
    return { error: 'That is not a permitted username' };
  }
  const user: UserRecord = {
    username,
    password,
    createdAt,
    display: username,
  };
  const id = randomUUID().toString();
  storedUsers[id] = user;
  usernameIndex[username] = id;
  return populateSafeUserInfo(id);
}

/**
 * Retrieves a single user from the database.
 *
 * @param username - The username of the user to find
 * @returns the found user object (without the password) or null
 */
export function getUserByUsername(username: string): SafeUserInfo | null {
  const id = usernameIndex[username];
  const user = storedUsers[id];
  if (!user) return null;
  return populateSafeUserInfo(id);
}

/**
 * Retrieves a list of usernames from the database
 *
 * @param usernames - A list of usernames
 * @returns the SafeUserInfo objects corresponding to those users
 * @throws if any of the usernames are not valid
 */
export function getUsersByUsername(usernames: string[]): SafeUserInfo[] {
  return usernames.map(username => {
    if (!(username in usernameIndex)) throw new Error('No such username');
    return storedUsers[usernameIndex[username]];
  });
}

/**
 * Updates user information in the database
 *
 * @param username - A valid username for the user to update
 * @param updates - An object that defines the fields to be updated and their new values
 * @returns the updated user object (without the password)
 * @throws if the username does not exist in the database
 */
export function updateUser(username: string, { display, password }: UserUpdateRequest) {
  const id = usernameIndex[username];
  const oldUser = storedUsers[id];
  const newUser = { ...oldUser };
  if (display !== undefined) newUser.display = display;
  if (password !== undefined) newUser.password = password;
  storedUsers[id] = newUser;
  return populateSafeUserInfo(id);
}
