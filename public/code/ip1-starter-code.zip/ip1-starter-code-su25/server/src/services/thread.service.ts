import { randomUUID } from 'node:crypto';
import {
  type CreateThreadMessage,
  type ThreadInfo,
  type ThreadSummary,
} from '@strategy-town/shared';
import { populateSafeUserInfo } from './user.service.ts';
import { createComment, populateCommentInfo } from './comment.service.ts';
import { type ObjectId, type Types, type UserWithId } from '../types.ts';

/**
 * Represents a forum post as it's stored in the database.
 * - `title`: post title
 * - `text`: post contents
 * - `createdAt`: when the thread was posted
 * - `createdBy`: username of OP
 * - `comments`: replies to the post
 */
interface ThreadRecord {
  title: string;
  text: string;
  createdAt: Date;
  createdBy: Types.ObjectId; // References User records
  comments: ObjectId[]; // References Comment records
}

let storedThreads: { [_id: string]: ThreadRecord } = {};

/** Reset stored threads with example data */
export function resetStoredThreads() {
  storedThreads = {
    abadcafeabadcafeabadcafe: {
      createdBy: 'user1id',
      createdAt: new Date(),
      title: 'Nim?',
      text: "Is anyone around that wants to play Nim? I'll be here for the next hour or so.",
      comments: [],
    },
    deadbeefdeadbeefdeadbeef: {
      createdBy: 'user1id',
      createdAt: new Date('2025-04-02'),
      title: 'Hello strategy townies',
      text: "I'm a big Nim buff and am excited to join this community.",
      comments: [],
    },
    [randomUUID().toString()]: {
      createdBy: 'user3id',
      createdAt: new Date(new Date().getTime() - 6 * 24 * 60 * 60 * 1000),
      title: 'Other games?',
      text: "Nim is great, but I'm hoping some new strategy games will get introduced soon.",
      comments: [],
    },
    [randomUUID().toString()]: {
      createdBy: 'user2id',
      createdAt: new Date('2025-04-04'),
      title: 'Strategy guide?',
      text: "I'm pretty confused about the right strategy for Nim, is there anyone around who can help explain this?",
      comments: [],
    },
    [randomUUID().toString()]: {
      createdBy: 'user0id',
      createdAt: new Date(new Date().getTime() - 1.5 * 24 * 60 * 60 * 1000),
      title: 'New game: multiplayer number guesser!',
      text: 'Strategy.town now has an exciting new game: guess! Try it out today: multiple people can join this exciting game, and guess a number between 1 and 100!',
      comments: [],
    },
  };
}

/**
 * Expand a stored thread
 *
 * @param _id - Valid thread id
 * @returns the expanded thread info object
 */
function populateThreadInfo(_id: string): ThreadInfo {
  const thread = storedThreads[_id];
  return {
    _id,
    title: thread.title,
    text: thread.text,
    createdBy: populateSafeUserInfo(thread.createdBy),
    createdAt: thread.createdAt,
    comments: thread.comments.map(populateCommentInfo),
  };
}

/**
 * Create and store a new thread
 *
 * @param user - The thread poster
 * @param contents - Title and text of the thread
 * @param createdAt - Creation time for this thread
 * @returns the new thread's info object
 */
export function createThread(
  user: UserWithId,
  { title, text }: CreateThreadMessage,
  createdAt: Date,
): ThreadInfo {
  const id = randomUUID().toString();
  const thread: ThreadRecord = {
    title,
    text,
    createdAt,
    createdBy: user._id,
    comments: [],
  };
  storedThreads[id] = thread;
  return populateThreadInfo(id);
}

/**
 * Retrieves a single thread from the database
 *
 * @param _id - Ostensible thread ID
 * @returns the thread, or null if no thread with that ID exists
 */
export function getThreadById(_id: string): ThreadInfo | null {
  const thread = storedThreads[_id];
  if (!thread) return null;
  return populateThreadInfo(_id);
}

/**
 * Get a list of all threads
 *
 * @returns a list of thread summaries, ordered reverse chronologically by creation date
 */
export function getThreadSummaries(): ThreadSummary[] {
  const unsorted = Object.entries(storedThreads).map(
    ([_id, { title, createdAt, createdBy, comments }]) => ({
      _id,
      title,
      createdAt,
      createdBy: populateSafeUserInfo(createdBy),
      comments: comments.length,
    }),
  );

  return unsorted.toSorted(
    (thread1, thread2) => thread2.createdAt.getTime() - thread1.createdAt.getTime(),
  );
}

/**
 * Add a comment id to a thread
 * @param threadId - Ostensible thread ID
 * @param user - Commenting user
 * @param text - Contents of the thread
 * @param createdAt - Creation time for thread
 * @returns the updated thread with comment attached, or null if the thread does not exist
 */
export function addCommentToThread(
  threadId: string,
  user: UserWithId,
  text: string,
  createdAt: Date,
): ThreadInfo | null {
  const oldThread = storedThreads[threadId];
  if (!oldThread) return null;
  const comment = createComment(user, text, createdAt);
  const newThread = { ...oldThread, comments: [...oldThread.comments, comment._id] };
  storedThreads[threadId] = newThread;
  return populateThreadInfo(threadId);
}
