import { randomUUID } from 'node:crypto';
import { type ChatInfo } from '@strategy-town/shared';
import { getMessagesById } from './message.service.ts';
import { type UserWithId } from '../types.ts';

/**
 * Represents a chat document in the database.
 * - `messages`: the ordered list of messages in the chat
 * - `createdAt`: when the chat was created
 */
interface ChatRecord {
  messages: string[]; // References Message models
  createdAt: Date;
}
const storedChats: { [_id: string]: ChatRecord } = {};

/**
 * Expand a stored chat
 *
 * @param _id - Valid chat id
 * @returns the expanded chat info object
 */
function populateChatInfo(_id: string): ChatInfo {
  const chat = storedChats[_id];
  return {
    _id,
    createdAt: chat.createdAt,
    messages: getMessagesById(chat.messages),
  };
}

/**
 * Creates and store a new chat
 *
 * @param createdAt - Time of chat creation
 * @returns the chat's info object
 */
export function createChat(createdAt: Date): ChatInfo {
  const id = randomUUID().toString();
  const chat: ChatRecord = {
    createdAt,
    messages: [],
  };
  storedChats[id] = chat;
  return populateChatInfo(id);
}

/**
 * Produces the chat for a given id
 *
 * @param chatId - Ostensible chat id
 * @param user - Authenticated user
 * @returns the chat's info object
 * @throws if the chat id is not valid
 */
export function forceChatById(chatId: string, user: UserWithId): ChatInfo {
  const chat = storedChats[chatId];
  if (!chat) throw new Error(`user ${user.username} accessed invalid chat id`);

  return populateChatInfo(chatId);
}

/**
 * Adds a message to a chat, updating the chat
 *
 * @param chatId - Ostensible chat id
 * @param user - Authenticated user
 * @param message - Valid message id
 * @returns the updated chat info object
 * @throws if the chat id is not valid
 */
export function addMessageToChat(chatId: string, user: UserWithId, messageId: string): ChatInfo {
  const chat = storedChats[chatId];
  if (!chat) throw new Error(`user ${user.username} sent to invalid chat id`);
  const newChat: ChatRecord = {
    ...chat,
    messages: [...chat.messages, messageId],
  };
  storedChats[chatId] = newChat;
  return populateChatInfo(chatId);
}
