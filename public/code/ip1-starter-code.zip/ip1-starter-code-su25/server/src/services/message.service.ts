import { type MessageInfo } from '@strategy-town/shared';
import { populateSafeUserInfo } from './user.service.ts';
import { randomUUID } from 'node:crypto';
import { type UserWithId } from '../types.ts';

/**
 * Represents a message in the database.
 * - `text`: message contents
 * - `createdBy`: username of message sender
 * - `createdAt`: when the message was sent
 */
interface MessageRecord {
  text: string;
  createdBy: string; // References User records
  createdAt: Date;
}
const storedMessages: { [_id: string]: MessageRecord } = {};

/**
 * Expand a stored message
 *
 * @param _id - Valid message id
 * @returns the expanded message info object
 */
function populateMessageInfo(_id: string): MessageInfo {
  const message = storedMessages[_id];
  return {
    _id,
    text: message.text,
    createdAt: message.createdAt,
    createdBy: populateSafeUserInfo(message.createdBy),
  };
}

/**
 * Creates and stores a new message
 *
 * @param user - a valid user
 * @param text - the message's text
 * @param createdAt - the time of message creation
 * @returns the message's info object
 */
export function createMessage(user: UserWithId, text: string, createdAt: Date): MessageInfo {
  const id = randomUUID().toString();
  const message: MessageRecord = {
    text,
    createdAt,
    createdBy: user._id,
  };
  storedMessages[id] = message;
  return populateMessageInfo(id);
}

/**
 * Retrieves a list of message ids from the database
 *
 * @param ids - A list of valid message ids
 * @returns the MessageInfo objects corresponding to those ids
 * @throws if any of the ids are not valid
 */
export function getMessagesById(ids: string[]): MessageInfo[] {
  return ids.map(populateMessageInfo);
}
