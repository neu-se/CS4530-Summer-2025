import { type CommentInfo } from '@strategy-town/shared';
import { populateSafeUserInfo } from './user.service.ts';
import { randomUUID } from 'node:crypto';
import { type Types, type UserWithId } from '../types.ts';

/**
 * Represents a comment in the database.
 * - `text`: comment contents
 * - `createdBy`: username of the commenter
 * - `createdAt`: when the comment was made
 * - `editedAt`: when the comment was last modified
 */
interface CommentRecord {
  text: string;
  createdBy: Types.ObjectId; // References User records
  createdAt: Date;
  editedAt?: Date;
}
const storedComments: { [_id: string]: CommentRecord } = {};

/**
 * Expand a stored comment
 *
 * @param _id - Valid comment id
 * @returns the expanded comment info object
 */
export function populateCommentInfo(_id: string): CommentInfo {
  const comment = storedComments[_id];
  return {
    _id,
    text: comment.text,
    createdAt: comment.createdAt,
    createdBy: populateSafeUserInfo(comment.createdBy),
    editedAt: comment.editedAt,
  };
}

/**
 * Creates and stores a new comment
 *
 * @param userId - a valid user id
 * @param text - the comment's text
 * @param createdAt - the time of comment creation
 * @returns the comment's info object
 */
export function createComment(user: UserWithId, text: string, createdAt: Date): CommentInfo {
  const id = randomUUID().toString();
  const comment: CommentRecord = {
    text,
    createdAt,
    createdBy: user._id,
  };
  storedComments[id] = comment;
  return populateCommentInfo(id);
}
