import { type Server, type Socket } from 'socket.io';
import { type Request, type Response } from 'express';
import {
  type ClientToServerEvents,
  type ServerToClientEvents,
  type TaggedGameView,
} from '@strategy-town/shared';

export type SocketAPI = (socket: StrategySocket, io: StrategyServer) => (payload: unknown) => void;

export type RestAPI<R = unknown, P = { [key: string]: string }> = (
  req: Request<P, R | { error: string }, unknown>,
  res: Response<R | { error: string }>,
) => void;

export type StrategyServer = Server<ClientToServerEvents, ServerToClientEvents>;
export type StrategySocket = Socket<ClientToServerEvents, ServerToClientEvents>;

// There may be a more elegant way to do things, but this is fundamentally
// a stopgap until we use true MongoDB object ids
// eslint-disable-next-line @typescript-eslint/no-namespace
export namespace Types {
  export type ObjectId = string;
}
export type ObjectId = string;

export interface GameViewUpdates {
  watchers: TaggedGameView;
  players: { userId: Types.ObjectId; view: TaggedGameView }[];
}

export interface UserWithId {
  _id: Types.ObjectId;
  username: string;
}
