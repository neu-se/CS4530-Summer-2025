// Run this script to launch the server.
/* eslint no-console: "off" */

import startServer from './app.ts';
import { resetStoredGames } from './services/game.service.ts';
import { resetStoredThreads } from './services/thread.service.ts';
import { resetStoredUsers } from './services/user.service.ts';

resetStoredUsers();
resetStoredThreads();
resetStoredGames();
startServer();
