import { describe, expect, it } from 'vitest';
import { enforceAuth } from '../../src/services/user.service.ts';

// enforceAuth isn't tested by current integration tests,
// because existing tests exercise the REST api, and enforceAuth
// is only used in the socket api
describe('enforceAuth', () => {
  it('should return a user and id on good auth', () => {
    const user = enforceAuth({ username: 'user1', password: 'pwd1' });
    expect(user).toStrictEqual({ _id: expect.any(String), username: 'user1' });
  });

  it('should raise on bad auth', () => {
    expect(() => enforceAuth({ username: 'user1', password: 'no' })).toThrow();
  });
});
