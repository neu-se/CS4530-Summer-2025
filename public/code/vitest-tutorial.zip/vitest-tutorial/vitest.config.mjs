import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['**/*.spec.ts'],
    exclude: ['.stryker-tmp/**', 'node_modules/**'],
    coverage: { provider: 'istanbul' },
  },
});
