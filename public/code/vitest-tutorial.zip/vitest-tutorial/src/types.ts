// types.ts - types for the transcript service

export type StudentID = number;
export type Student = { studentID: number; studentName: StudentName };
export type Course = string;
export type CourseGrade = { course: Course; grade: number };
export type Transcript = { student: Student; grades: CourseGrade[] };
export type StudentName = string;

export interface TranscriptService {
  addStudent(studentName: string): StudentID;
  getTranscript(id: StudentID): Transcript;
  deleteStudent(id: StudentID): void; // hmm, what to do about errors??
  addGrade(id: Student, course: Course, courseGrade: CourseGrade): void;
  getGrade(id: Student, course: Course): CourseGrade;
  nameToIDs(studentName: string): StudentID[];
}
