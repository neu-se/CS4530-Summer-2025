import { beforeEach, describe, expect, it } from 'vitest';
import TranscriptDB from '../src/transcript.service.ts';
import type { TranscriptService } from '../src/types.ts';

let db: TranscriptService;

// start each test with a fresh empty database.
beforeEach(() => {
  db = new TranscriptDB();
});

// this may look undefined in TSC until you do an npm install
// and possibly restart VSC.
describe('addStudent', () => {
  it('should add a student to the database and return their id', () => {
    // const db = new DataBase ()
    expect(db.nameToIDs('blair')).toStrictEqual([]);
    const id1 = db.addStudent('blair');
    expect(db.nameToIDs('blair')).toStrictEqual([id1]);
  });

  it('should return an ID distinct from any ID in the database', () => {
    // we'll just add 3 students and check to see that their IDs
    // are all different.
    const id1 = db.addStudent('blair');
    const id2 = db.addStudent('corey');
    const id3 = db.addStudent('delta');
    expect(id1).not.toBe(id2);
    expect(id1).not.toBe(id3);
    expect(id2).not.toBe(id3);
  });

  it('should permit adding a student w/ same name as an existing student', () => {
    const id1 = db.addStudent('blair');
    const id2 = db.addStudent('blair');
    expect(id1).not.toBe(id2);
  });

  it('should give newly added students an empty transcript', () => {
    const id1 = db.addStudent('blair');
    const retrievedTranscript = db.getTranscript(id1);
    expect(retrievedTranscript.grades).toStrictEqual([]);
    expect(retrievedTranscript.student).toStrictEqual({
      studentID: id1,
      studentName: 'blair',
    });
  });
});

describe('getTranscript', () => {
  it("should return the student's transcript when given an ID", () => {
    // add a student, getting an ID
    // add some grades for that student
    // retrieve the transcript for that ID
    // check to see that the retrieved grades are
    // exactly the ones you added.
  });

  it('should throw an error when given an ID that is not the ID of any student', () => {
    // in an empty database, all IDs are bad :)
    // Note: the expression you expect to throw must be wrapped in a (() => ...)
    expect(() => db.getTranscript(1)).toThrowError();

    // This will not work correctly, because the expression is not wrapped
    // It's worth uncommenting this line and seeing what happens, though!
    // expect(db.getTranscript(1)).toThrowError()
  });
});
