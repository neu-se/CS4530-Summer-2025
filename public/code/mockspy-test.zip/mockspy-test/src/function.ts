import { api, type ErrorMsg } from './api';

const ENDPOINT = 'https://robsimmons--35f6863b568a4a758f409962d90629e6.web.val.run';

export interface ExpectedResponse {
  seenBefore: number;
  isAlphaNum: boolean;
  isSecret: boolean;
}

export default async function fn(word: string) {
  try {
    const res = await api.post<ErrorMsg | ExpectedResponse>(ENDPOINT, { word });
    if ('error' in res.data) {
      return res.data;
    }
    if (res.data.isSecret) {
      return { code: 1, seenBefore: res.data.seenBefore };
    }
    if (res.data.isAlphaNum) {
      return { code: 2, seenBefore: res.data.seenBefore };
    }
    if (res.data.seenBefore === 0) {
      return { code: 3, seenBefore: res.data.seenBefore };
    }
    return { code: 4, seenBefore: res.data.seenBefore };
  } catch {
    return { success: false, error: 'something went wrong' };
  }
}
