import { describe, expect, it } from 'vitest';
import fn from './function';

describe('the fn() function', () => {
  it('should increase seenBefore on repeated calls', async () => {
    const r1 = (await fn('bord')) as any;
    const r2 = (await fn('word')) as any;
    expect(r1).toStrictEqual({
      code: expect.any(Number),
      seenBefore: expect.any(Number),
    });
    expect(!('error' in r1));
    expect(!('error' in r2));
    expect(r2.seenBefore).toBeGreaterThan(r1.seenBefore);
  });
});
