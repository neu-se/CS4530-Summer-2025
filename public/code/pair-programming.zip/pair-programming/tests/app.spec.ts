import { describe, expect, it } from 'vitest';
import supertest, { type Response } from 'supertest';
import { app } from '../src/app.ts';

let response: Response;

describe('POST /analyze', () => {
  it('should return 500 on ill-formed payloads', async () => {
    response = await supertest(app).post('/analyze');
    expect(response.status).toBe(500);

    response = await supertest(app).post('/analyze').send({ bad: 'input' });
    expect(response.status).toBe(500);
  });

  it('Should return word counts given "Hello Hello World" as input', async () => {
    response = await supertest(app).post('/analyze').send({ text: 'hello hello world' });
    expect(response.status).toBe(200);
    expect(response.body).toStrictEqual({ hello: 2, world: 1 });
  });
});
