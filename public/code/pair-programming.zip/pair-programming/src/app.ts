/* eslint no-console: "off" */

import express, { type Request, type Response } from 'express';
import { z } from 'zod';

export const app = express();
app.use(express.json());

type RequestType = z.infer<typeof zRequestType>;
const zRequestType = z.object({ text: z.string() });

type ResponseType = z.infer<typeof zResponseType>;
const zResponseType = z.object({}).catchall(z.number());

app.post('/analyze', (request: Request<{}, never, unknown>, response: Response<ResponseType>) => {
  const body: RequestType = zRequestType.parse(request.body);
  response.send({ hello: 2, world: 1 });
});

