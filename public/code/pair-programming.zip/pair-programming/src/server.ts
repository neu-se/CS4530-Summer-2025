// Run this script to launch the server.
/* eslint no-console: "off" */

import { app } from './app.ts';

export default function startServer() {
  app.listen(8010, () => {
    console.log(`Server is running on port 8010`);
  });
}
startServer();
