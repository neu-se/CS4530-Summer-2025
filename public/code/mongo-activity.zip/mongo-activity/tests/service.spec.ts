import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import transcriptService from '../src/service.ts';
import { CourseGradeModel, TranscriptModel } from '../src/models.ts';

// MongoDB in-memory server instance for testing
let mongoServer: MongoMemoryServer;

// Set up the MongoDB connection before tests
beforeAll(async () => {
  // Create an in-memory MongoDB instance
  mongoServer = await MongoMemoryServer.create();
  const mongoUri = mongoServer.getUri();

  // Connect to the in-memory MongoDB
  await mongoose.connect(mongoUri);
});

// Clean up resources after all tests
afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

// Clear all data before each test and add some sample data
beforeEach(async () => {
  await CourseGradeModel.deleteMany({});
  await TranscriptModel.deleteMany({});
  const [grade1, grade2] = await CourseGradeModel.insertMany([
    { course: 'Basketweaving', grade: 99 },
    { course: 'Algorithms', grade: 100 },
  ]);
  await TranscriptModel.insertOne({
    studentId: 5,
    studentName: 'Bob',
    grades: [grade1._id, grade2._id],
  });
});

describe('addStudent', () => {
  it('should return different ids for two students with the same name', async () => {
    const id1 = await transcriptService.addStudent('Andrea');
    const id2 = await transcriptService.addStudent('Andrea');
    expect(id1).not.toBe(id2);
  });
});

describe('getTranscript', () => {
  it('should return existing user transcript', async () => {
    const preloadedUser = await transcriptService.getTranscript(5);

    expect(preloadedUser).toStrictEqual({
      studentId: 5,
      studentName: 'Bob',
      grades: [
        { course: 'Basketweaving', grade: 99 },
        { course: 'Algorithms', grade: 100 },
      ],
    });
  });

  it('should error for a nonexistent id', async () => {
    await expect(transcriptService.getTranscript(-1)).rejects.toThrow();
  });

  it('should return a transcript for a newly added student', async () => {
    const id = await transcriptService.addStudent('Nalini');

    const transcript = await transcriptService.getTranscript(id);
    expect(transcript).toStrictEqual({
      studentId: id,
      studentName: 'Nalini',
      grades: [],
    });
  });
});

describe('addGrade', () => {
  it('should error for an invalid student id', async () => {
    await expect(transcriptService.addGrade(-1, 'Fake course', 12)).rejects.toThrow();
  });

  it('should add a new grade for a new student', async () => {
    const id = await transcriptService.addStudent('Rob');
    await transcriptService.addGrade(id, 'Laser Cutting', 12);
    const transcript = await transcriptService.getTranscript(id);
    expect(transcript).toStrictEqual({
      studentId: id,
      studentName: 'Rob',
      grades: [{ course: 'Laser Cutting', grade: 12 }],
    });
  });

  it('should add additional grades to the end', async () => {
    await transcriptService.addGrade(5, 'Laser Cutting', 12);
    const transcript = await transcriptService.getTranscript(5);
    expect(transcript).toStrictEqual({
      studentId: 5,
      studentName: 'Bob',
      grades: [
        { course: 'Basketweaving', grade: 99 },
        { course: 'Algorithms', grade: 100 },
        { course: 'Laser Cutting', grade: 12 },
      ],
    });
  });
});
