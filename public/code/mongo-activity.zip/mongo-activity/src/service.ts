import { CourseGradeModel, TranscriptModel } from './models.ts';
import type { TranscriptDocument, TranscriptService } from './types.ts';

const transcriptService: TranscriptService = {
  getTranscript: async (id: number) => {
    const transcript = await TranscriptModel.findOne({ studentId: id });
    if (!transcript) throw new Error('Unknown id');
    return transcript.toJSON() as unknown as TranscriptDocument;
  },

  addGrade: async (id: number, course: string, courseGrade: number) => {
    const grade = await CourseGradeModel.insertOne({ course: course, grade: courseGrade });
    return Promise.reject(new Error('Unimplemented'));
  },

  addStudent: async (newName: string) => {
    // This is a bad way to come up with a new student id!
    // We're doing it anyway.
    const id = Math.floor(Math.random() * 1_000_000_000);
    await TranscriptModel.insertOne({
      studentId: id,
      studentName: newName,
      grades: [],
    });
    return id;
  },
};
export default transcriptService;
