import mongoose from 'mongoose';

export interface CourseGradeDocument {
  course: string;
  grade: string;
}

// These interfaces describe our data
export interface Student {
  studentName: string;
}

export interface TranscriptDocument {
  studentId: number;
  studentName: string;
  grades: mongoose.Types.ObjectId[] | CourseGradeDocument[];
}

export type StudentID = number;
export type Course = string;
export type CourseGrade = string;

/**
 * Interface for MongoTranscriptService class
 */
export interface TranscriptService {
  addStudent(newName: string): Promise<number>;
  getTranscript(id: number): Promise<TranscriptDocument>;
  addGrade(id: number, course: string, courseGrade: number): Promise<void>;
}
