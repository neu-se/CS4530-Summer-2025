import mongoose, { type InferSchemaType, Schema } from 'mongoose';

export type CourseGradeRecord = InferSchemaType<typeof courseGradeSchema>;
const courseGradeSchema: Schema = new Schema({
  course: { type: String, required: true },
  grade: { type: Number, required: true },
});

export const CourseGradeModel = mongoose.model<CourseGradeRecord>('CourseGrade', courseGradeSchema);

export type TranscriptRecord = InferSchemaType<typeof transcriptSchema>;
const transcriptSchema: Schema = new Schema({
  studentId: { type: Number, required: true, unique: true },
  studentName: { type: String, required: true },
  grades: {
    type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'CourseGrade', required: true }],
    required: true,
  },
});

export const TranscriptModel = mongoose.model<TranscriptRecord>('Transcript', transcriptSchema);
